// Declare grid as a global variable
let grid;
let walls = [];
let targetCellsToAdd = 1; // Default number of target cells to add
let startNode = null;
let goalNode = null;

// The Node class represents a cell in the grid
class Node {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.isWall = false;
    this.isStart = false;
    this.isGoal = false;
    this.goalIndex = -1;
    this.parent = null;
    this.g = 0;
    this.h = 0;
    this.f = 0;
    // this.stepsFromStart = 0;
  }
}

// Heuristic functions, these functions help us guess the distance between points
const heuristic = {
  manhattan: (node, goal) => Math.abs(node.x - goal.x) + Math.abs(node.y - goal.y),
  euclidean: (node, goal) => Math.sqrt(Math.pow(node.x - goal.x, 2) + Math.pow(node.y - goal.y, 2)),
};

// A* Algorithm is our way to find a path on a map
function aStar(start, goal, grid, heuristicFunc) {
  let openSet = [start];
  let closedSet = [];
  let path = [];
  start.g = 0;
  start.f = heuristicFunc(start, goal);
  let testedNodes = 0;

  document.getElementById('testedNodesList').innerHTML = '';

  while (openSet.length > 0) {
    let current = openSet.reduce((acc, node) => (node.f < acc.f ? node : acc), openSet[0]);
    if (current === goal) {
      let temp = current;
      let steps = 0;
      while (temp.previous) {
        steps++;
        path.push(temp);
        temp = temp.previous;
      }
      document.getElementById('stepsAndNodesCount').textContent = 'Steps: ' + steps + ', Tested Nodes: ' + testedNodes;
      return path.reverse();
    }

    openSet = openSet.filter(node => node !== current);
    closedSet.push(current);
    testedNodes++;

    addTestedNodeToList(current);

    let neighbors = getNeighbors(current, grid);
    neighbors.forEach(neighbor => {
      if (!closedSet.includes(neighbor) && !neighbor.isWall) {
        let tempG = current.g + 1;
        let newPath = false;
        if (openSet.includes(neighbor)) {
          if (tempG < neighbor.g) {
            neighbor.g = tempG;
            newPath = true;
          }
        } else {
          neighbor.g = tempG;
          newPath = true;
          openSet.push(neighbor);
        }
        if (newPath) {
          neighbor.h = heuristicFunc(neighbor, goal);
          neighbor.f = neighbor.g + neighbor.h;
          neighbor.previous = current;
        }
      }
    });
  }

  document.getElementById('stepsAndNodesCount').textContent = 'Steps: 0, Tested Nodes: ' + testedNodes;
  return [];
}

// Function to add a tested node to the testedNodesList in the UI
function addTestedNodeToList(node) {
  const testedNodesList = document.getElementById('testedNodesList');
  const listItem = document.createElement('li');
  listItem.textContent = `Tested Node: (x: ${node.x}, y: ${node.y})`;
  testedNodesList.appendChild(listItem);
}

// Function to return an array of valid neighbors for the current node
function getNeighbors(node, grid) {
  const dirs = [
    [1, 0],
    [0, 1],
    [-1, 0],
    [0, -1]
  ];
  return dirs.map(dir => {
    const [dx, dy] = dir;
    const x = node.x + dx,
      y = node.y + dy;
    if (x >= 0 && x < grid.length && y >= 0 && y < grid[0].length) {
      return grid[x][y];
    }
  }).filter(n => n !== undefined);
}

// Setting up the grid for use
function createGrid(width, height) {
  grid = new Array(height);
  for (let x = 0; x < height; x++) {
    grid[x] = new Array(width);
    for (let y = 0; y < width; y++) {
      grid[x][y] = new Node(x, y);
    }
  }
}

// Display function to draw the grid
function drawGrid() {
  const gridContainer = document.getElementById('gridContainer');
  gridContainer.innerHTML = ''; // Clear previous grid
  gridContainer.style.gridTemplateColumns = `repeat(${grid[0].length}, 30px)`; // Set the number of columns based on grid width

  grid.forEach((row, x) => {
    row.forEach((node, y) => {
      const element = document.createElement('div');
      element.classList.add('node');
      element.id = `node-${x}-${y}`; // Assign ID based on node's x and y coordinates

      // Add click event listener to toggle walls and set start/goal
      element.addEventListener('click', () => {
        if (!startNode && !node.isGoal && !node.isWall) {
          setStartOrGoal(node, 'start');
          element.classList.add('start');
        } else if (goalNodes.length < targetCellsToAdd && !node.isStart && !node.isWall) {
          // Allow setting multiple goals based on targetCellsToAdd
          setStartOrGoal(node, 'goal');
          element.classList.add('goal');
        } else if (!node.isStart && !node.isGoal) {
          toggleWall(node);
          element.classList.toggle('blocked');
        }
        updateNodeVisuals(node, element);
      });

      // Set the initial class if this node is a wall, start, or goal
      updateNodeVisuals(node, element);

      gridContainer.appendChild(element);
    });
  });
}

// Making sure we know where to start and finish
function setStartOrGoal(node, type, goalIndex = 0) {
 if (type === 'start') {
    if (startNode) {
      startNode.isStart = false;
    }
    startNode = node;
    startNode.isStart = true;
  } else if (type === 'goal') {
    // This time we can have multiple goals
    if (goalNode) {
      // If there is already a goals set isGoal to false
      node.isGoal = false;
      node.goalIndex = -1;
    } else {
      // Set as a new goal
      node.isGoal = true;
      node.goalIndex = goalIndex;
      goalNodes.push(node); // Add to goal nodes array
    }
  }
}

// Use an array to store goal nodes
let goalNodes = [];

// Letting us block off areas of the grid
function toggleWall(node) {
  node.isWall = !node.isWall;
  if (node.isWall) {
    walls.push(node);
  } else {
    walls = walls.filter(w => w !== node);
  }
}

// Making sure we can click on each square
document.getElementById('createGrid').addEventListener('click', () => {
  const width = parseInt(document.getElementById('width').value, 10);
  const height = parseInt(document.getElementById('height').value, 10);
  targetCellsToAdd = parseInt(document.getElementById('numTargets').value, 10); // Update target cells to add
  createGrid(width, height);
  drawGrid();
  document.getElementById('createGrid').disabled = true;
  document.getElementById('createGrid').style.backgroundColor = 'grey';
  document.getElementById('createGrid').style.cursor = 'not-allowed';
});

// Run A* for each goal and determine the shortest path
document.getElementById('runAStar').addEventListener('click', () => {
  // Reset the step count in the HTML
  document.getElementById('stepsAndNodesCount').textContent = 'Steps: 0, Tested Nodes: 0';

 

  if (!startNode || goalNodes.length === 0) {
    alert('Please set a start and at least one goal node.');
    return;
  }


  let heuristicMethod = document.getElementById('heuristic').value;
  let heuristicFunc = heuristic[heuristicMethod]; // Fetch the heuristic function based on user selection

  let shortestPath = [];
  let shortestLength = Infinity;

  goalNodes.forEach((goalNode, index) => {
    const path = aStar(startNode, goalNode, grid, heuristicFunc); // Use the selected heuristic function
    if (path.length > 0 && path.length < shortestLength) {
      shortestPath = path;
      shortestLength = path.length;
    }
  });

  if (shortestPath.length === 0) {
    alert('No path found to any of the goals!');
    return;
  }

  // Visualize the shortest path
  visualizePath(shortestPath);
});


function visualizePath(path) {
  path.forEach(node => {
    const element = document.getElementById(`node-${node.x}-${node.y}`);
    element.classList.add('path');
  });
}

// Giving each square an ID so we know where to click
function updateNodeVisuals(node, element) {
  element.className = 'node'; // Reset class name to default
  if (node.isWall) {
    element.classList.add('blocked');
  }
  if (node.isStart) {
    element.classList.add('start');
  }
  if (node.isGoal) {
    element.classList.add('goal');
  }
}
